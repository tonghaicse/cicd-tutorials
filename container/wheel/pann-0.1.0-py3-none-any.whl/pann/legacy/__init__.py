"""
Legacy PANN modules.

Copyright 2018-2020 Qiuqiang Kong. MIT license.
See https://github.com/qiuqiangkong/audioset_tagging_cnn.
"""
