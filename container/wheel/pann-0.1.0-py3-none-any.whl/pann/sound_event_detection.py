"""Sound event detection."""

import numpy as np

from pann import _model_args, labels
from pann.base import PANN
from pann.legacy.models import Cnn14_DecisionLevelMax


class CNN14Max(PANN):
    """CNN14-Max model for sound event detection.

    Args:
        sample_rate: A positive integer representing the sample rate.
          Defaults to 44100.
        hop_size: A positive integer representing the hop size.
          Defaults to 441.

    Attributes:
        sample_rate: A positive integer representing the sample rate.
        hop_size: A positive integer representing the hop size.
    """

    def __init__(self, sample_rate: int = 44100, hop_size: int = 441):
        """Initializes self."""
        super().__init__(sample_rate=sample_rate, hop_size=hop_size)
        self._model = Cnn14_DecisionLevelMax(**{
            **_model_args, 'sample_rate': sample_rate, 'hop_size': hop_size
        })

    def predict(self, audio):
        """Predicts sound events.

        Args:
            audio: A 1d float32 numpy array representing audio data
              sampled at self.sample_rate. The length must be at least
              513 and 31 times self.hop_size. The values are assumed
              to be between -1.0 and 1.0, but this is not checked.

        Returns:
            A 2d numpy array with the (i,j)th entry being the
            probability that the jth label in pann.labels is positive
            at the ith time step. Each time step has duration in
            seconds equal to self.hop_size divided by self.sample_rate.
        """
        output = super().predict(audio)
        output = output['framewise_output'].data.cpu().numpy()[0]
        if output.ndim != 2 or output.shape[1] != len(labels):
            raise ValueError('Unexpected output shape')
        # ceiling division
        ntimestep = -(len(audio) // -self.hop_size)
        return np.resize(output, (ntimestep, len(labels)))
