"""Audio tagging."""

from pann import _model_args, labels
from pann.base import PANN
from pann.legacy.models import Cnn14


class CNN14(PANN):
    """CNN14 model for audio tagging.

    Args:
        sample_rate: A positive integer representing the sample rate.
          Defaults to 44100.
        hop_size: A positive integer representing the hop size.
          Defaults to 441.

    Attributes:
        sample_rate: A positive integer representing the sample rate.
        hop_size: A positive integer representing the hop size.
    """

    def __init__(self, sample_rate: int = 44100, hop_size: int = 441):
        """Initializes self."""
        super().__init__(sample_rate=sample_rate, hop_size=hop_size)
        self._model = Cnn14(**{
            **_model_args, 'sample_rate': sample_rate, 'hop_size': hop_size
        })

    def predict(self, audio):
        """Predicts audio tags.

        Args:
            audio: A 1d float32 numpy array representing audio data
              sampled at self.sample_rate. The length must be at least
              513 and 31 times self.hop_size. The values are assumed
              to be between -1.0 and 1.0, but this is not checked.

        Returns:
            A 1d numpy array with the ith entry being the probability
            that the ith label in pann.labels is positive.
        """
        output = super().predict(audio)
        output = output['clipwise_output'].data.cpu().numpy()[0]
        if output.shape != (len(labels),):
            raise ValueError('Unexpected output shape')
        return output
