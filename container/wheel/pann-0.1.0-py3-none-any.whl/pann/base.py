"""Base classes."""

import numpy as np
import torch


class PANN:
    """Base class for PANNs.

    This class should not be used directly. All pretrained models must
    extend this class.
    """

    def __init__(self, sample_rate: int = 44100, hop_size: int = 441):
        """Initializes self."""
        self.sample_rate = _check_pos_int(sample_rate)
        self.hop_size = _check_pos_int(hop_size)
        # minimum valid audio length
        self._mval = max(513, 31 * self.hop_size)
        # define self._model
        ...

    def load(self, path: str):
        """Loads model from file.

        Args:
            path: Path to pth model file.

        Returns:
            self: Loaded object.
        """
        self._model.load_state_dict(
            torch.load(path, map_location='cpu')['model']
        )
        return self

    def predict(self, audio):
        """Predicts audio."""
        if not audio.dtype == np.float32:
            raise ValueError('audio data must have dtype float32')
        if not audio.shape >= (self._mval,):
            raise ValueError(
                'audio length must be at least 513'
                ' and 31 times self.hop_size'
            )
        with torch.no_grad():
            self._model.eval()
            return self._model(torch.as_tensor(audio[None]), None)
        # process output
        ...


def _check_pos_int(value: int) -> int:
    """Checks that the input value is a positive integer."""
    integer = int(value)
    if integer != value or integer <= 0:
        raise ValueError(f'not a positive integer: {value}')
    return integer
